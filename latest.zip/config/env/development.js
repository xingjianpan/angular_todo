//loaded by config.js

module.exports = {
	db: 'mongodb://localhost/meanbook_1',
  sessionSecret: 'developmentSessionSecret'
};

