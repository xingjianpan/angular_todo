exports.config = {
  specs: ['public/*[!lib]*/tests/e2e/*.js']
}